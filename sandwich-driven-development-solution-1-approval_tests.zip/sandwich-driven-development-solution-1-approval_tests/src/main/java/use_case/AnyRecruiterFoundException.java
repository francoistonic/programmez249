package use_case;

public class AnyRecruiterFoundException extends RuntimeException {
}
