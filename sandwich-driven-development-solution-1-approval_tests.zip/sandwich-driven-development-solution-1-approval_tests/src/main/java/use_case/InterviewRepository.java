package use_case;

import model.Interview;

public interface InterviewRepository {
    void save(Interview interview);
}
