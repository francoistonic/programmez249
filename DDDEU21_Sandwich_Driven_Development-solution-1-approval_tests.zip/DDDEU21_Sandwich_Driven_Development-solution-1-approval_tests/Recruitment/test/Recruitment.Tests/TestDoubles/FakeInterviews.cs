﻿using Recruitment.Domain.Interviews;

namespace Recruitment.Tests.TestDoubles
{
    public class FakeInterviews : IInterviewRepository
    {
        public void Save(Interview interview)
        {
            
        }
    }
}