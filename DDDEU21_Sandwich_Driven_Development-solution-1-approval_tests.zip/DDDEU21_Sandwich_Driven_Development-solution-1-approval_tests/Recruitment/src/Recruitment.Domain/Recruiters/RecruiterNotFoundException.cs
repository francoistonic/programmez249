﻿using System;

namespace Recruitment.Domain.Recruiters
{
    public class RecruiterNotFoundException : Exception
    {
        
    }
}